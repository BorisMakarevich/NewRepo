$(window).on('load', function(){

    // Vide.js-video background
    $('#header').vide('./video/cover', {
        bgColor: '#bc8a67'
    });

});